# cycle_planner

A new Flutter project.

## Team members: Sayem Ahmed, Badr Almakky, Ammar Alshareef, Arham Azhary, Maya Dejonge, Hadwa El Toubshy, Muhammad Jawad, Mahmood Ndanusa, Katinka Singh

(link for deployment){[https://appetize.io/app/d9vfdtm65qaxnm4q6f6wbuwbpm?device=pixel4&osVersion=12.0&scale=75]

Below you should find the sources which any code may have been reused to the best of our knowledge.

- [mapbox_naviation.dart uses this site for code](https://pub.dev/packages/flutter_mapbox_navigation)
- [a large number of tests from google maps was used and can be found here](https://github.com/flutter/plugins/tree/main/packages/google_maps_flutter/google_maps_flutter)
- guides to set up flutter, dart and android studio can be found in the developers setup PDF
