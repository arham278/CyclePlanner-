package com.example.cycle_planner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
